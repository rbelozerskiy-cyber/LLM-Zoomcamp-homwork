import sqlite3
from pathlib import Path

import pandas as pd

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)


DB_PATH = "traces.db"

# Каждый запуск начинает чистую серию из четырёх RAG-вызовов.
Path(DB_PATH).unlink(missing_ok=True)


class SQLiteSpanExporter(SpanExporter):
    def __init__(self, db_path=DB_PATH):
        self.conn = sqlite3.connect(db_path)

        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS spans (
                name TEXT,
                start_time INTEGER,
                end_time INTEGER,
                input_tokens INTEGER,
                output_tokens INTEGER,
                cost REAL
            )
            """
        )

        self.conn.commit()

    def export(self, spans):
        for span in spans:
            attrs = dict(span.attributes or {})

            self.conn.execute(
                """
                INSERT INTO spans (
                    name,
                    start_time,
                    end_time,
                    input_tokens,
                    output_tokens,
                    cost
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    span.name,
                    span.start_time,
                    span.end_time,
                    attrs.get("input_tokens"),
                    attrs.get("output_tokens"),
                    attrs.get("cost"),
                ),
            )

        self.conn.commit()
        return SpanExportResult.SUCCESS

    def shutdown(self):
        if self.conn is not None:
            self.conn.close()
            self.conn = None

    def force_flush(self, timeout_millis=30_000):
        return True


provider = TracerProvider()
sqlite_exporter = SQLiteSpanExporter(DB_PATH)

provider.add_span_processor(
    SimpleSpanProcessor(sqlite_exporter)
)

trace.set_tracer_provider(provider)
tracer = trace.get_tracer("llm-zoomcamp")


from starter import index, client
from rag_helper import RAGBase


def calculate_cost(usage) -> float:
    return (
        usage.input_tokens * 0.15
        + usage.output_tokens * 0.60
    ) / 1_000_000


class RAGTraced(RAGBase):
    def search(self, query, num_results=5):
        with tracer.start_as_current_span("search"):
            return super().search(
                query,
                num_results=num_results,
            )

    def llm(self, prompt):
        with tracer.start_as_current_span("llm") as span:
            response = super().llm(prompt)
            usage = response.usage

            span.set_attribute(
                "input_tokens",
                usage.input_tokens,
            )
            span.set_attribute(
                "output_tokens",
                usage.output_tokens,
            )
            span.set_attribute(
                "cost",
                calculate_cost(usage),
            )

            return response

    def rag(self, query):
        with tracer.start_as_current_span("rag"):
            return super().rag(query)


def run_four_queries():
    rag = RAGTraced(
        index=index,
        llm_client=client,
    )

    query = (
        "How does the agentic loop keep calling "
        "the model until it stops?"
    )

    for run_number in range(1, 5):
        print(f"\nRunning RAG call {run_number}/4...")

        answer = rag.rag(query)

        print(
            f"Completed run {run_number}. "
            f"Answer length: {len(answer)} characters."
        )


def analyze_database():
    conn = sqlite3.connect(DB_PATH)

    try:
        df = pd.read_sql_query(
            "SELECT * FROM spans",
            conn,
        )
    finally:
        conn.close()

    df["duration_ms"] = (
        df["end_time"] - df["start_time"]
    ) / 1_000_000

    print("\n" + "=" * 70)
    print("Q4 — SPAN NAMES")
    print("=" * 70)

    span_names = sorted(df["name"].unique().tolist())
    print(span_names)

    print("\nRows by span name:")
    print(df["name"].value_counts())

    print("\n" + "=" * 70)
    print("Q5 — TOTAL DURATION EXCLUDING RAG")
    print("=" * 70)

    duration_summary = (
        df[df["name"] != "rag"]
        .groupby("name", as_index=False)["duration_ms"]
        .sum()
        .sort_values("duration_ms", ascending=False)
    )

    print(duration_summary.to_string(index=False))

    print("\nLongest child span type:")
    print(duration_summary.iloc[0]["name"])

    print("\n" + "=" * 70)
    print("Q6 — INPUT TOKEN STABILITY")
    print("=" * 70)

    input_tokens = (
        df.loc[df["name"] == "llm", "input_tokens"]
        .dropna()
        .astype(int)
        .tolist()
    )

    print(f"Input tokens across four runs: {input_tokens}")

    minimum = min(input_tokens)
    maximum = max(input_tokens)

    if minimum == maximum:
        variation_percent = 0.0
        category = "They are identical"
    else:
        variation_percent = (
            (maximum - minimum) / minimum
        ) * 100

        if variation_percent <= 10:
            category = "Within 10% of each other"
        elif variation_percent <= 50:
            category = "Within 50% of each other"
        else:
            category = "They vary more than 50%"

    print(f"Variation: {variation_percent:.2f}%")
    print(f"Answer category: {category}")

    print("\n" + "=" * 70)
    print("DATABASE SUMMARY")
    print("=" * 70)
    print(f"Total rows: {len(df)}")
    print(df.to_string(index=False))


def main():
    run_four_queries()

    # Все экспорты синхронные, но shutdown явно закрывает БД
    # перед чтением её через pandas.
    provider.shutdown()

    analyze_database()


if __name__ == "__main__":
    main()