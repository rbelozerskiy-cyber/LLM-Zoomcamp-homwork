from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    ConsoleSpanExporter,
    SimpleSpanProcessor,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)


# OpenTelemetry необходимо настроить до импорта starter.
provider = TracerProvider()

console_exporter = ConsoleSpanExporter()
memory_exporter = InMemorySpanExporter()

provider.add_span_processor(
    SimpleSpanProcessor(console_exporter)
)
provider.add_span_processor(
    SimpleSpanProcessor(memory_exporter)
)

trace.set_tracer_provider(provider)
tracer = trace.get_tracer("llm-zoomcamp")


from starter import index, client
from rag_helper import RAGBase


def calculate_cost(usage) -> float:
    """
    Тарифы из учебного материала для gpt-5.4-mini:
    $0.15 / 1M входных и $0.60 / 1M выходных токенов.
    """
    return (
        usage.input_tokens * 0.15
        + usage.output_tokens * 0.60
    ) / 1_000_000


class RAGTraced(RAGBase):
    def search(self, query, num_results=5):
        with tracer.start_as_current_span("search"):
            return super().search(
                query,
                num_results=num_results,
            )

    def llm(self, prompt):
        with tracer.start_as_current_span("llm") as span:
            response = super().llm(prompt)
            usage = response.usage

            span.set_attribute(
                "input_tokens",
                usage.input_tokens,
            )
            span.set_attribute(
                "output_tokens",
                usage.output_tokens,
            )
            span.set_attribute(
                "cost",
                calculate_cost(usage),
            )

            return response

    def rag(self, query):
        with tracer.start_as_current_span("rag"):
            return super().rag(query)


def main():
    rag = RAGTraced(
        index=index,
        llm_client=client,
    )

    query = (
        "How does the agentic loop keep calling "
        "the model until it stops?"
    )

    answer = rag.rag(query)

    print("\n" + "=" * 70)
    print("ANSWER")
    print("=" * 70)
    print(answer)

    spans = memory_exporter.get_finished_spans()

    print("\n" + "=" * 70)
    print("SUMMARY FOR Q1-Q3")
    print("=" * 70)
    print(f"Number of spans: {len(spans)}")

    for span in spans:
        duration_ms = (
            span.end_time - span.start_time
        ) / 1_000_000

        attrs = dict(span.attributes or {})

        print(
            f"name={span.name:8s} | "
            f"duration={duration_ms:.2f} ms | "
            f"input_tokens={attrs.get('input_tokens')} | "
            f"output_tokens={attrs.get('output_tokens')} | "
            f"cost={attrs.get('cost')}"
        )


if __name__ == "__main__":
    main()